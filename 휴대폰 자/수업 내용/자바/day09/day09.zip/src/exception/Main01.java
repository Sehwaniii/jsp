package exception;

public class Main01 {

	public static void main(String[] args) {
		String year1 = "1980";
		int age1 = 2023 - Integer.parseInt(year1);
		System.out.println(age1);
		
		String year2 = "자바학생";
		int age2 = 2023 - Integer.parseInt(year2);
		System.out.println(age2);
		
		System.out.println("--------프로그램 종료------------");
		
		
	}

}













