package Interface;

public interface Action {
	public void pickup();
}
