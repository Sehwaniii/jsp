package override;

// 부모 클래스
public class Hello2 {
	Hello2( String msg ){
		System.out.println(msg);
	}
}
