package override;

public class User {
	private String name;

	public User(String name) {
		super();
		this.name = name;
	}
	
	
}
