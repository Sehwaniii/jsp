package override;

public class Main01 {

	public static void main(String[] args) {
		Korean k = new Korean();
		k.sayHello();
		
		
	}

}
