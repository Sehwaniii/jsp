package overload;

public class Main01 {

	public static void main(String[] args) {
		/*
		 * 오버로드는 하나의 메서드를 호출할 수 있는
		 * 모든 경우의 수를 미리 준비해 놓음으로서,
		 * 메서드를 만드는 측은 번거로울 수 있지만
		 * 메서드를 호출하는 측은 데이터 타입을 신경쓰지 않고
		 * 편리하게 사용할 수 있게 하기 위함이다.  
		 */
		System.out.println();
	}

}







