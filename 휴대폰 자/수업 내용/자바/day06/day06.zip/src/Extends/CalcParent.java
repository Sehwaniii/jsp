package Extends;

public class CalcParent {
	// 생성자를 특별히 정의하지 않는 경우, 기본 생성자가 있다고 간주한다.
		
	public int plus(int x, int y) {
		return x+y;
	}
	
	public int minus(int x, int y) {
		return x-y;
	}
	
}
