package sington;

public class Main01 {

	public static void main(String[] args) {
//		Calc c1 = new Calc();
//		int a = c1.plus(100, 200);
//		
//		Calc c2 = new Calc();
//		int b = c2.minus(200, 100);
//		
//		Calc c1 = new Calc();
//		int a = c1.plus(100, 200);
//		int b = c1.minus(100, 200);
//		
		
	}

}
