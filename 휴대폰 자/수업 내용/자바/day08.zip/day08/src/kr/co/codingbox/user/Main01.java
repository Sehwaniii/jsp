package kr.co.codingbox.user;

import kr.co.cordingbox.article.Article;

//import kr.co.cordingbox.article.Article;

public class Main01 {

	public static void main(String[] args) {
		
		kr.co.cordingbox.article.Article a1 = new Article(1, "게시글", "2023");
		
	}

}
