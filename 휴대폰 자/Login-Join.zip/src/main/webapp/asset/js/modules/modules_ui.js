function map_A010( gon ) {
	$(gon).closest('[data-module-name="map_A010"]').addClass('map_contents_hide');
}